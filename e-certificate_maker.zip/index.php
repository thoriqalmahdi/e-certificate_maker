<?php 
include "config/settings.php";
?>


<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="utf-8">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<title>Math UIN SGD</title>
	<meta charset="UTF-8">
	<meta name="description" content="Official Website Mathematic UIN Sunan Gunung Jati - Bandung">
	<meta name="keywords" content="math uin, uin bandung">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- Favicon -->   
	<link href="img/logo.png" rel="shortcut icon"/>

	<!-- Google Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">

	<!-- Stylesheets -->
	<link rel="stylesheet" href="css/bootstrap.min.css"/>
	<link rel="stylesheet" href="css/font-awesome.min.css"/>
	<link rel="stylesheet" href="css/themify-icons.css"/>
	<link rel="stylesheet" href="css/animate.min.css"/>
	<link rel="stylesheet" href="css/magnific-popup.css"/>
	<link rel="stylesheet" href="css/owl.carousel.min.css"/>
	<link rel="stylesheet" href="css/style.css"/>

	<!--[if lt IE 9]>
	  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->
	
	<style type="text/css">
	    #whatsapp a {
  font-size: 18px;
  background: #ffbc00;
  border: none;
  color: #000;
  font-weight: 500;
  padding: 15px 50px;
  border-radius: 50px;
  min-width: 160px;
  cursor: pointer;
  -webkit-box-shadow: 0px 20px 50px 0px rgba(55, 56, 56, 0.2);
  box-shadow: 0px 20px 50px 0px rgba(55, 56, 56, 0.2);
  -webkit-transition: all 0.3s;
  -o-transition: all 0.3s;
  transition: all 0.3s;
}

#whatsapp a:hover {
  color: #fff;
  background: #0a0e1f;
}

.contact-form ::-webkit-input-placeholder {
  font-style: italic;
  color: #fff;
}

.contact-form ::-ms-input-placeholder {
  font-style: italic;
  color: #fff;
}

.contact-form :-ms-input-placeholder {
  font-style: italic;
  color: #fff;
}

.contact-form ::placeholder {
  font-style: italic;
}
	</style>

</head>
<body>

<!-- Preloder start -->
	<div id="preloder">
		<div class="loader"></div>
	</div>
<!-- Preloder end -->

<!-- Header section start -->
	<header class="header-section">
		<div class="container">
			<div class="header-warp">
				<!-- Site Logo -->
				<a href="#" class="site-logo">
					<img src="img/logo.png" alt="">
					  Math UIN
				</a>
				<!-- Site Menu -->
				<div class="responsive-switch"><i class="fa fa-bars"></i></div>
				<nav class="site-menu">
					<div class="sm-close"><i class="ti-close"></i></div>
					<ul class="menu-list">
						<li><a href="#home">Home</a></li>
						<li><a href="#quote">Gasss</a></li>
						
					</ul>
				</nav>
			</div>
		</div>
	</header>
<!-- Header section end -->



<!-- Quote section start -->
	<section class="resume-section spad" id="quote">
		<div class="container pt-1">
			<div class="section-title">
				<h3>E-Certificate Maker</h3>
				<hr>
			</div>
			<div class="row">
				<div class="col-lg-10 col-xl-9 offset-lg-2 offset-xl-2">
					
						<form method="POST" enctype="multipart/form-data">
							<div class="form-row">
								<div class="col-md-6">
							
									<div class="form-group">
										<label style="color:#FFFFFF;">Submit Nama :</label>
										<input class="form-control" type="text" name="nama">
									</div>
									<div class="form-group">
										<label style="color:#FFFFFF;">Submit Nomor :</label>
										<input class="form-control" type="text" name="nomor">
									</div>
									<div class="form-group">
										<input class="waves-effect btn btn-primary" type="submit" value="Gasss" name="execute">
									</div>
								    </div>
								    <div class="form-group col-md-6">		
									<?php if (empty($_POST)): ?>
										<label style="color:#FFFFFF;">Preview :</label>
										<img src="files/eser/eser.png"/>
									<?php endif ?>
									<?php  include "module/uin/execute.php";?>
										<br>
										<p style="color:#FFFFFF;">* Klik Untuk Download</p>
								</div>
							</div>
						</form>

					</div>
				</div>
				<hr>
			</div>
				
		</div>
	</section>

<!-- Quote section start -->















<!--====== Jquery & Javascripts files  ======-->
	<script src="js/jquery-2.1.4.min.js"></script>
	<script src="js/jquery.nav.min.js"></script>
	<script src="js/isotope.pkgd.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/magnific-popup.min.js"></script>
	<script src="js/wow.min.js"></script>
	<script src="js/typed.min.js"></script>
	<script>/*
==============================================
	KNIT
	Version: 1.0
	Author: BootEx
	Author URL: http://www.ahadhossain.com
------------------------------------------------
================================================
*/

'use strict';

$(window).on('load', function() { 
	/*------------------
		Preloder
	--------------------*/
	$(".loader").fadeOut(); 
	$("#preloder").delay(100).fadeOut("slow");


	/*------------------
	Isotope Filter
	--------------------*/
	var $container = $('.isotope_items');
	$container.isotope();

	$('.portfolio-filter li').on("click", function(){
		$(".portfolio-filter li").removeClass("active");
		$(this).addClass("active");				 
		var selector = $(this).attr('data-filter');
		$(".isotope_items").isotope({
				filter: selector,
				animationOptions: {
				duration: 750,
				easing: 'linear',
				queue: false,
			}
		});
		return false;
	});

});


(function($){

	/*------------------
		Navigation
	--------------------*/
	$('.responsive-switch').on('click', function(e) {
		$('.site-menu').toggleClass('active');	
		e.preventDefault();
	});

	$('.menu-list>li>a, .sm-close').on('click', function() {
		$('.site-menu').removeClass('active');
	});

	$('.menu-list').onePageNav({
		easing: 'swing'
	});


	/*------------------
		Hero section
	--------------------*/
	var hero_h = $('.hero-section').innerHeight(),
		body_h = $('body').innerHeight(),
		header_height =  hero_h - body_h;

	$(window).on('scroll resize',function(e) {
		if ($(this).scrollTop() > header_height) {
			$('.hero-content').addClass('sticky');
		}else{
			$('.hero-content').removeClass('sticky');
		}
		e.preventDefault();
	});



	/*------------------
		Typed js
	--------------------*/
	if($('#typed-text').length > 0 ) {
		var typed2 = new Typed('#typed-text', {
		   	strings: ["Selamat Datang", "Matematika Sains UIN SGD" ],
			typeSpeed: 90,
			loop:false,
			backDelay: 2000
		});
	}

	/*------------------
		Typed js
	--------------------*/
	if($('#typed-text2').length > 0 ) {
		var typed2 = new Typed('#typed-text2', {
		   	strings: ["Bhadrika Danadyaksa ~ Bersama Menjunjung Kejayaan" ],
			typeSpeed: 120,
			loop:false,
			backDelay: 2000
		});
	}



	/*------------------
		Background set
	--------------------*/
	$('.set-bg').each(function() {
		var bg = $(this).data('setbg');
		$(this).css('background-image', 'url(' + bg + ')');
	});


	/*------------------
		PROGRESS BAR
	--------------------*/
	$('.progress-bar-style').each(function() {
		var progress = $(this).data("progress");
		var prog_width = progress + '%';
		if (progress <= 100) {
			$(this).append('<div class="bar-inner" style="width:' + prog_width + '"><span>' + prog_width + '</span></div>');
		}
		else {
			$(this).append('<div class="bar-inner" style="width:100%"><span>100%</span></div>');
		}
	});



	/*------------------
		Popup
	--------------------*/
	$('.work-image').magnificPopup({
		type: 'image',
		removalDelay: 400,
		zoom:{enabled: true, duration: 300}
	});

	$('.work-video').magnificPopup({
		type: 'iframe',
	});



	/*------------------
		Service
	--------------------*/
	$('.service-slider').owlCarousel({
		loop:true,
		autoplay:true,
		nav:false,
		dots: false,
		margin:30,
		responsive:{
			0:{
				items:1
			},
			720:{
				items:2
			},
			992:{
				items:3
			}
		}
	});



	/*------------------
		Testimonial
	--------------------*/
	$('.review-slider').owlCarousel({
		dots: false,
		nav: true,
		loop: true,
		margin:30,
		smartSpeed: 700,
		items:1,
		autoplay:true,
		navText: ['<i class="ti-arrow-left"></i>', '<i class="ti-arrow-right"></i>']
	});


	/*------------------
		WOW JS
	--------------------*/
	new WOW().init();


	/*------------------
		CONTACT FORM
	--------------------*/
	$('#contact-form').on('submit', function() {
		var send_btn = $('#send-form'),
			form = $(this),
			formdata = $(this).serialize(),
			chack = $('#form-chack');
			send_btn.text('Wait...');

		function reset_form(){
		 	$("#name").val('');
			$("#email").val('');
			$("#massage").val('');
		}

		$.ajax({
			url:  $(form).attr('action'),
			type: 'POST',
			data: formdata,
			success : function(text){
				if (text == "success"){
					send_btn.addClass('done');
					send_btn.text('Success');
					setTimeout(function() {
						reset_form();
						send_btn.removeClass('done');
						send_btn.text('Send Massage');
					}, 3000);
				}
				else {
					reset_form();
					send_btn.addClass('error');
					send_btn.text('Error');
					setTimeout(function() {
						send_btn.removeClass('error');
						send_btn.text('Send Massage');
					}, 5000);
				}
			}
		});
		return false;
	});

})(jQuery);</script>




<!-- WhatsApp Fiture -->
<script src="js/wa.js"></script>

<?php  
	if (!empty($_SESSION['execute'])) {
		echo $_SESSION['execute'];
		unset($_SESSION['execute']);
	}

	include "template/author.php";
	?>

</html>