<?php

if(isset($_POST['execute'])) {

	echo "<label><font color=white>Result :</font></label>";

	//Main Setting
	$folder = "files/eser/";
	$overlay = $folder."eser.png";
	$font_nama = realpath("files/_font/"."Ubuntu-Medium.ttf");
	$font_nomor = realpath("files/_font/"."Ubuntu-Medium.ttf");
	$nama = @$_POST['nama'] ? $_POST['nama'] : 'YOUR NAME';
	$nomor = @$_POST['nomor'] ? $_POST['nomor'] : 'YOUR NOMOR';
	$filename = @$nama.".png";
	
	$backgrond = @$_POST['background'];

	if (!filter_var($backgrond, FILTER_VALIDATE_URL) === false) {
					$bg = $backgrond;
				}else {		
					$bg = get_redirect_target('files/eser/eser.png');
				}

	// Set Posisi nama
	$image = new PHPImage();
	$image->setQuality(10);
	$image->setDimensionsFromImage($overlay);
	$image->draw($bg);
	$image->draw($overlay, '50%', '75%');
	$image->setFont($font_nama);
	$image->setTextColor(array(255, 255, 255));
	$image->setAlignVertical('center');
	$image->setAlignHorizontal('center');
	$image->textBox($nama, array(   //nama
		'fontSize' => 40, 
		'x' => 0,
		'y' => -75,
		'width' => 1056,
		'height' => 816,
		'debug' => false
		));

	// Set Posisi Nomor
	$image->setFont($font_nomor);
	$image->setTextColor(array(255, 255, 255));	
	$image->text($nomor, array(
		'fontSize' => 12, 
		'x' => 40,
		'y' => 173,
		'width' => 640,
		'height' => 20,
		'debug' => false
		));






	$image->save($filename);





	$imagebase64 = "data:image/png;base64,".base64_encode(file_get_contents($filename));
	echo "<a href='".$imagebase64."' target='_blank' download='$filename'><img src='".$imagebase64."'/></a>";
	unlink($filename);
}

?>