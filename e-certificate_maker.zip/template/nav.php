<li class="waves-block waves-effect">
	<a href="./">
		<i class="icon icon-lg icon-th-list"></i>
		Dashboard
	</a>

<li class="waves-block waves-effect">
	<a href="?module=sgbquote">
		<i class="icon icon-lg icon-th-list"></i>
		SGB Quote
	</a>
</li> 
<!-- 
remove ~
<li class="waves-block waves-effect">
	<a href="?module=fakektp">
		<i class="icon icon-lg icon-th-list"></i>
		Fake KTP
	</a>
</li>  -->