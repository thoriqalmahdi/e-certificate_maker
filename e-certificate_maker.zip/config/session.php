<?php  
session_start();
?>