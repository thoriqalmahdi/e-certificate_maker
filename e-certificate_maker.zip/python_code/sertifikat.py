from selenium import webdriver
import time

#list nama
#pastikan list diawali dan diakhiri oleh "Dummy Text"
file = open('list_nama.txt', "r")
data = file.readlines()

#selenium
driver = webdriver.Chrome('C:\chromedriver.exe') #lokasi webdriver
time.sleep(2)
driver.get("http://localhost/e-certificate_maker/") #link localhost/web

#address xpath
xpath = "/html/body/section/div/div[2]/div/form/div/"

#mulai nomor sertifikat
nomor = 1


#main loop
for i in range(len(data)):
    nama = data[i]
    time.sleep(3)
    driver.find_element_by_xpath("{}div[1]/div[1]/input".format(xpath)).send_keys(nama)
    time.sleep(2)
    driver.find_element_by_xpath("{}div[1]/div[2]/input".format(xpath)).send_keys(nomor)
    driver.find_element_by_xpath("{}div[2]/a/img".format(xpath)).click()
    print("[{}] -- {}".format(nomor, data[i]))
    nomor = nomor + 1
    
    
    